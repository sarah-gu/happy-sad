# Handoff: Happy‑Sad (Tamagotchi‑style mood wheel)

## Overview

**Happy‑Sad** is a tiny, single‑viewport web app with a retro Tamagotchi / pixel‑LCD aesthetic. The user picks a mood (happy or sad), spins a prize wheel, and gets a randomized suggestion: an activity (if happy) or a small pick‑me‑up message (if sad). A pixel‑art pet paces along the bottom of every screen as ambient charm.

The product is meant to feel like a single object — a handheld pixel toy — not a typical web page. It should fill the viewport, not scroll.

## About the design files

The file in `reference/happy-sad.html` is a **design reference**, built in plain HTML + React (Babel in the browser) so it can run in any preview. **Do not ship this HTML.** Recreate the design in a real Next.js application using the project's existing patterns. The HTML's structure, copy, colors, type, animation timings, and pixel‑art sprites are all authoritative; the implementation approach (inline Babel, vanilla CSS in `<style>`, etc.) is not.

## Fidelity

**High‑fidelity.** Colors, type sizes, spacing, animation timings, and the pixel sprites (face icons + pet) are final. Recreate them pixel‑accurately. If the target codebase already has a global design system that conflicts, ask before substituting — this product's identity is the retro pixel look.

## Target stack

- **Next.js** (App Router preferred; Pages Router fine if that's what the codebase uses)
- **React 18+**
- **TypeScript** if the codebase uses it
- Styling: whatever the codebase uses (CSS Modules, Tailwind, vanilla CSS, etc.). The design uses small, focused CSS — adapting it to any approach is straightforward.
- No data fetching, no auth, no persistence required. Entirely client‑side state.

## Fonts

Two Google Fonts. Load via `next/font/google` rather than `<link>` tags.

| Family | Use |
|---|---|
| `Press Start 2P` | Headings, labels, buttons, badges — everywhere "blocky pixel" type is wanted |
| `VT323` | Body copy inside the reveal card (the quote text), and as the default page font |

Pixel rendering hints (apply to the page root):

```css
font-family: "VT323", "Press Start 2P", monospace;
-webkit-font-smoothing: none;
image-rendering: pixelated;
```

## Design tokens

```css
--bg:         #ede4cb;  /* warm cream — page background */
--bg-2:       #e3d9bb;  /* slightly darker cream — panels, buttons */
--ink:        #1a1d1f;  /* near‑black — text, borders, sprite outlines */
--ink-soft:   #3a3d3f;  /* secondary text */
--pink:       #f0a4be;  /* happy accent */
--pink-soft:  #f7cfdc;  /* happy bg tint */
--blue:       #8ec2dd;  /* sad accent */
--blue-soft:  #c8e1ee;  /* sad bg tint */
--yellow:     #f6d36a;  /* pet body */
--yellow-soft:#fbe7a5;
--green:      #a4c994;
--peach:      #f3b58a;
```

Title‑specific colors (only used on the landing word "HAPPY‑SAD"):

- `HAPPY` text fill: `#d96a8a`, drop‑shadow `3px 3px 0 var(--pink-soft)`
- `SAD`   text fill: `#4f8fbf`, drop‑shadow `3px 3px 0 var(--blue-soft)`
- Dash:   `var(--ink)`

Reveal‑card mood tinting:

- `mood-happy` card background: `var(--pink-soft)`; badge background: `var(--pink)`
- `mood-sad`   card background: `var(--blue-soft)`; badge background: `var(--blue)`

## Layout / fundamentals

- Page is a **single viewport, no scroll** (`html, body { height: 100%; overflow: hidden; }`).
- Root `.app` is full‑viewport, with a faint LCD dot grid as background:
  ```css
  background-image: radial-gradient(rgba(26,29,31,0.06) 1px, transparent 1px);
  background-size: 6px 6px;
  ```
- The pet layer is absolutely positioned at the bottom of `.app` and is present on **every** screen.
- All buttons use a hard, offset, no‑blur "pixel" drop shadow (e.g. `box-shadow: 6px 6px 0 var(--ink)`). On `:active` they translate down/right by the shadow offset and the shadow shrinks, simulating a press. Transitions use `steps(2)` for a chunky, non‑smooth feel.

## Screens

There are three screens, switched via local state. No routing. Use a single `useState<"landing" | "wheel" | "reveal">` (or whatever idiom the codebase prefers).

### 1. Landing

**Purpose:** ask the user how they feel.

**Layout:** centered column. Title at top, two square choice tiles side by side below.

**Title:** `<h1>` with three spans (`HAPPY`, `-`, `SAD`). `Press Start 2P`, `clamp(28px, 5.5vw, 56px)`, `letter-spacing: 2px`, centered. Margin below: `clamp(36px, 6vh, 64px)`.

**Choice tiles:** two `<button>` elements in a flex row with `gap: clamp(24px, 5vw, 64px)`. Each tile:

- Square, `width: clamp(160px, 22vw, 220px)`, `aspect-ratio: 1`.
- 4px solid `--ink` border, 18px padding.
- Background: `--pink-soft` (happy) / `--blue-soft` (sad). Hover: `--pink` / `--blue`.
- `box-shadow: 6px 6px 0 var(--ink)`. Active: translate 4px,4px; shadow → `2px 2px 0`.
- Centered inside: a 9×9 pixel face SVG (see "Pixel face" below), `currentColor`.
- Below each tile, absolutely positioned at `bottom: -34px`, a label: `Press Start 2P`, 11px, letter‑spacing 2px, color `--ink-soft`. Text: `HAPPY` / `SAD`.

Click → set mood, navigate to wheel.

### 2. Wheel

**Purpose:** spin to randomize a result.

**Layout:** centered column.

- Back button top‑left (`< BACK`), see "Back button" below.
- Heading: `Press Start 2P`, `clamp(14px, 2vw, 18px)`, letter‑spacing 2px, centered. Text:
  - happy → `PICK AN ACTIVITY`
  - sad   → `PICK A PICK‑ME‑UP`
- Wheel (see "Wheel component") at `width/height: min(64vh, 460px)`.
- Spin button below wheel (`Press Start 2P`, 13px, 4px ink border, 14×28 padding, `box-shadow: 5px 5px 0 var(--ink)`, hover lightens, active translates 4,4).

**Spin button text:** `SPIN` normally, `...` while spinning. Disabled during spin.

**Center hub of wheel** is also a clickable circular button (`SPIN`), 76×76px, 4px ink border, `box-shadow: 0 4px 0 var(--ink)`. Same disabled behavior. So users can press either the hub OR the button below.

### 3. Reveal

**Purpose:** show the randomized result with a confetti burst.

**Layout:** centered column. `< HOME` back button top‑left.

**Reveal card:**

- Padding: `clamp(24px, 4vw, 40px) clamp(28px, 5vw, 56px)`.
- `max-width: 620px`, `width: 92%`.
- 4px solid `--ink` border, `box-shadow: 8px 8px 0 var(--ink)`.
- Background tinted by mood (see tokens).
- Entry animation: `pop 0.32s steps(4) both` — scale from 0.6 → 1, opacity 0 → 1, **`steps(4)`** (chunky, not smooth).
- Badge: absolutely positioned at `top: -16px, left: 50%, translateX(-50%)`. `Press Start 2P` 10px, letter‑spacing 2px, 3px ink border, `padding: 4px 12px`, `box-shadow: 3px 3px 0 var(--ink)`. Background tinted by mood. Shows the option's `label` (e.g. `BUILD`).
- Pixel face (mini, 64×64px) below the badge — matches mood. Has a blink animation:
  ```css
  animation: blink 3.4s steps(1) infinite;
  /* 0%,96%,100% opacity 1; 97%,99% opacity 0.3 */
  ```
- Quote text: `VT323`, `clamp(22px, 3.4vw, 32px)`, line‑height 1.15, color `--ink`.
- Optional attribution row in `VT323` 18px, color `--ink-soft`, opacity 0.8 (present in CSS, not currently used — safe to omit).
- Two action buttons in a flex row with 12px gap, wrap, centered: **SPIN AGAIN** (returns to wheel screen, same mood), **HOME** (returns to landing). Both use the same `spin-btn` styling.

**Confetti** fires on reveal — see "Confetti" below.

## Components

### Pixel face (`<PixelFace smile boolean>`)

A 9×9 pixel face drawn in SVG with `<rect>` cells. `currentColor` is used so it inherits text color. `viewBox="0 0 9 9"`, `shape-rendering="crispEdges"`.

Pixel positions to draw (each is a 1×1 `rect`):

**Outline (both faces):**
```
(2,0)(3,0)(4,0)(5,0)(6,0)
(1,1)(7,1)
(0,2)(8,2)
(0,3)(8,3)
(0,4)(8,4)
(0,5)(8,5)
(0,6)(8,6)
(1,7)(7,7)
(2,8)(3,8)(4,8)(5,8)(6,8)
```

**Eyes (both):** `(2,3)`, `(6,3)`

**Mouth — smile (happy):** `(2,5)(6,5)` (corners up) + `(3,6)(4,6)(5,6)` (bottom row). The smile sits one row above the bottom border for breathing room — do not put any mouth pixels at y=7.

**Mouth — frown (sad):** `(2,7)(6,7)` (corners down) + `(3,6)(4,6)(5,6)` (top row).

### Pet (`<Pet>`)

A 14×14 pixel sprite that paces left↔right across the bottom of `.app` on every screen.

**Sprite frames** — two near‑identical frames, only the feet positions differ to create a walking shuffle. Use a string‑grid mapping char → color. Chars:

- `X` = `#1a1d1f` (outline)
- `@` = `#f6d36a` (body, yellow)
- `E` = `#1a1d1f` (eye)
- `C` = `#f0a4be` (cheek blush)
- `M` = `#a04860` (mouth)
- `L`, `R` = `#1a1d1f` (feet)
- `.` = transparent (skip)

**Frame A** (feet inset):
```
....XXXXXX....
...X@@@@@@X...
..X@@@@@@@@X..
.X@@@@@@@@@@X.
.X@EE@@@@EE@X.
X@@EE@@@@EE@@X
X@@@@@@@@@@@@X
X@C@@@@@@@@C@X
X@@@@MMMM@@@@X
X@@@@@@@@@@@@X
.X@@@@@@@@@@X.
..XX@@@@@@XX..
...LL@@@@RR...
...LL....RR...
```

**Frame B** (feet wider apart):
```
....XXXXXX....
...X@@@@@@X...
..X@@@@@@@@X..
.X@@@@@@@@@@X.
.X@EE@@@@EE@X.
X@@EE@@@@EE@@X
X@@@@@@@@@@@@X
X@C@@@@@@@@C@X
X@@@@MMMM@@@@X
X@@@@@@@@@@@@X
.X@@@@@@@@@@X.
..XX@@@@@@XX..
..LL@@@@@@RR..
...LL....RR...
```

Render as a `<svg viewBox="0 0 14 14" shape-rendering="crispEdges">` with one `<rect width="1" height="1">` per non‑`.` cell. Toggle frame every **220ms** (`setInterval`).

**Blinking:** every 2.2–5.4s (randomized), close the eyes for 140ms. When closed, hide the four `E` pixels and draw a single thin horizontal line on row y=4 only (e.g. a `rect y={4.5} height={0.5}` at each eye x). Schedule the next blink recursively.

**Walking animation** (CSS):
```css
.pet {
  position: absolute;
  bottom: 16px; left: 0;
  width: 56px; height: 56px;
  image-rendering: pixelated;
  animation: pet-walk 26s linear infinite;
  will-change: transform;
}
@keyframes pet-walk {
  0%   { transform: translateX(-12px) scaleX(1); }
  48%  { transform: translateX(calc(100vw - 56px)) scaleX(1); }
  50%  { transform: translateX(calc(100vw - 56px)) scaleX(-1); }
  98%  { transform: translateX(-12px) scaleX(-1); }
  100% { transform: translateX(-12px) scaleX(1); }
}
```

**Body bob** (separate inner element so it composes with the walk transform on the parent):
```css
.pet-bob { width: 100%; height: 100%; animation: pet-bob 0.36s steps(2) infinite; }
@keyframes pet-bob {
  0%, 100% { transform: translateY(0); }
  50%      { transform: translateY(-2px); }
}
```

**Ground line** behind the pet:
```css
.pet-ground {
  position: absolute; left: 0; right: 0; bottom: 12px;
  height: 2px;
  background-image: linear-gradient(to right, var(--ink) 0 8px, transparent 8px 16px);
  background-size: 16px 2px;
  opacity: 0.28;
}
```

**Wrapper** that holds ground + pet on every screen:
```css
.pet-layer {
  position: absolute; left: 0; right: 0; bottom: 0;
  height: 72px;
  pointer-events: none;
  z-index: 6;
  overflow: hidden;
}
```

### Wheel

SVG wheel, 500×500 internal viewBox, scaled to `min(64vh, 460px)`.

- Outer circle radius `r = 250 − 12 = 238`. Draw an ink ring (`r+4`, fill `--ink`) under a `--bg` disc (`r`).
- N segments where N = number of options for the current mood (8 each). `segDeg = 360 / N`.
- Each segment is a pie slice path with a 3px `--ink` stroke. Alternate fill: even index → `--bg-2`, odd index → `--pink-soft` (happy) or `--blue-soft` (sad).
- Inside each segment, a `<text>` label rotated to align radially: `font-family: Press Start 2P`, `font-size: 20`, fill `--ink`, anchored at `(x,y)` at radius `r * 0.66` from center, rotated by `mid` degrees about that point.
- Accent dots: tiny `r=4` circles with 2px ink stroke at radius `r-22`, one per segment. Fill = `--pink` (happy) / `--blue` (sad).
- Pointer at top: an SVG triangle pointing down, positioned above the wheel center, filled with the mood accent.
- Center hub: an absolutely positioned circular `<button>` (76px, 4px ink border, hard ink shadow). Same click target as the SPIN button.
- Spin animation: rotate the SVG via inline `transform: rotate(${rotation}deg)`. Transition: `transform 4.6s cubic-bezier(.17,.85,.2,1)`.

**Spin logic:**

```ts
function spin() {
  if (spinning) return;
  const n = segments.length;
  const segDeg = 360 / n;
  const target = Math.floor(Math.random() * n);          // winning index
  const jitter = (Math.random() - 0.5) * segDeg * 0.8;   // don't land dead center
  const turns = 5 + Math.floor(Math.random() * 3);       // 5–7 full rotations
  const baseFloor = Math.floor(rotationRef.current / 360) * 360;
  const final = baseFloor + turns * 360 + (360 - target * segDeg) + jitter;
  rotationRef.current = final;
  setRotation(final);
  setSpinning(true);
  setTimeout(() => {
    setSpinning(false);
    setWinner(segments[target]);
    setScreen("reveal");
    triggerConfetti();
  }, 4700);
}
```

Keep `rotation` monotonically increasing (don't reset between spins) so the CSS transition always rotates forward.

### Back button

```css
.back {
  position: absolute; top: 22px; left: 22px;
  font-family: "Press Start 2P", monospace;
  font-size: 11px;
  letter-spacing: 1px;
  background: var(--bg-2);
  border: 3px solid var(--ink);
  padding: 8px 12px;
  cursor: pointer;
  box-shadow: 4px 4px 0 var(--ink);
  z-index: 10;
}
```

Active state translates 3,3 and shrinks shadow to `1px 1px 0`. Text: `< BACK` on the wheel screen, `< HOME` on the reveal screen.

### Confetti

On reveal, spawn 60 absolutely positioned, fixed‑layer pieces falling from `top: -16px` to past the bottom of the viewport. Each piece:

- Random `left` (0–100vw)
- Random horizontal drift `--dx` between −90 and +90px
- Random size: 4, 6, 8, or 10px square
- Random duration: 1800–3400ms
- Random delay: 0–500ms
- Random color from: `--pink`, `--blue`, `--yellow`, `--green`, `--peach`, and `--ink` (ink piece = ~1 in 6 chance)

```css
.confetti-layer { position: fixed; inset: 0; pointer-events: none; z-index: 50; overflow: hidden; }
.confetti-piece { position: absolute; top: -16px; animation: fall linear forwards; }
@keyframes fall {
  0%   { transform: translate3d(0, -10vh, 0); }
  100% { transform: translate3d(var(--dx, 0), 110vh, 0); }
}
```

Clear all pieces from state after 4500ms so they don't accumulate.

## Content / copy

The wheel options are arrays of `{ label, text }`. **Use these exactly.**

```ts
const HAPPY = [
  { label: "BUILD", text: "Build something with LEGO, blocks, or whatever's lying around." },
  { label: "MOVE",  text: "Go for a run, a walk, or a little dance break." },
  { label: "TEXT",  text: "Text 3 friends just to say hi." },
  { label: "SNACK", text: "Make your favorite snack and eat it slowly." },
  { label: "DRAW",  text: "Doodle, sketch, or color for 10 minutes. No rules." },
  { label: "SONG",  text: "Put on a song you LOVE and play it loud." },
  { label: "THANK", text: "Write down 3 things you're grateful for right now." },
  { label: "CALL",  text: "Call someone you haven't talked to in a while." },
];

const SAD = [
  { label: "REAL",  text: "You're allowed to have a bad day. Just don't unpack and live there." },
  { label: "SOFT",  text: "Even the sun has bad days behind the clouds. It always comes back." },
  { label: "DUCK",  text: "Plot twist — you're stronger than you think. Like, weirdly strong." },
  { label: "OK",    text: "Your feelings are valid. So is ice cream for dinner." },
  { label: "BRAVE", text: "Brave isn't never feeling sad. It's feeling sad and showing up." },
  { label: "NOW",   text: "Tomorrow is another chance. So is the next 10 minutes." },
  { label: "VIBE",  text: "You're a whole vibe, even when the vibe is grumpy." },
  { label: "PASS",  text: "This too shall pass. Probably while you're brushing your teeth." },
];
```

## State

All client‑side. Suggested shape:

```ts
type Screen = "landing" | "wheel" | "reveal";
type Mood = "happy" | "sad" | null;
type Option = { label: string; text: string };

const [screen, setScreen] = useState<Screen>("landing");
const [mood, setMood] = useState<Mood>(null);
const [rotation, setRotation] = useState(0);  // monotonically increasing
const rotationRef = useRef(0);
const [spinning, setSpinning] = useState(false);
const [winner, setWinner] = useState<Option | null>(null);
const [confettiKey, setConfettiKey] = useState(0); // increment to re‑fire confetti
```

Transitions:

- `pickMood(m)` → set mood, reset rotation/winner, screen → `wheel`
- `spin()` → see "Spin logic" above; after 4700ms → screen → `reveal`, increment confettiKey
- `spinAgain()` → clear winner, screen → `wheel` (keep mood)
- `reset()` / `home()` → clear mood + winner, screen → `landing`

## Suggested Next.js file layout

```
app/
  layout.tsx          # loads Press Start 2P + VT323 via next/font/google, sets <html> font vars
  page.tsx            # renders <HappySad />
  globals.css         # CSS variables (tokens), .app dot-grid, pet keyframes, confetti keyframes
components/
  HappySad.tsx        # top-level state machine; renders Landing/Wheel/Reveal + Pet + Confetti
  Landing.tsx
  WheelScreen.tsx
  Wheel.tsx           # the SVG wheel
  Reveal.tsx
  PixelFace.tsx
  Pet.tsx
  Confetti.tsx
data/
  options.ts          # HAPPY + SAD arrays
```

Mark `components/HappySad.tsx` (or whichever holds state) `"use client"`. Page itself can stay a server component that just renders the client component.

## Accessibility

- Choice tiles include `aria-label="I'm happy"` / `aria-label="I'm sad"`.
- Decorative SVGs (pet, ground line, confetti, wheel pointer, face icons inside buttons) should be `aria-hidden="true"`.
- The pet layer must have `pointer-events: none` so it never blocks clicks on the wheel/buttons underneath.
- Reduced motion: ideally honor `prefers-reduced-motion` by removing the pet walk, body bob, confetti fall, blink, and pop animations (or shortening durations to ~0). Not required for v1.

## Animation timing reference

| Animation | Duration | Easing | Loop |
|---|---|---|---|
| Pet walk (full lap) | 26s | linear | infinite |
| Pet body bob | 360ms | `steps(2)` | infinite |
| Pet frame swap | 220ms (interval) | — | infinite |
| Pet blink interval | random 2.2–5.4s | — | recursive |
| Pet blink duration | 140ms | — | — |
| Wheel spin | 4.6s (CSS transition) | `cubic-bezier(.17,.85,.2,1)` | one‑shot |
| Reveal card pop | 320ms | `steps(4)` | one‑shot |
| Face mini blink | 3.4s | `steps(1)` | infinite |
| Confetti fall | 1800–3400ms | linear | one‑shot |
| Button press | 80ms | `steps(2)` | — |

## Out of scope (do not add)

- Persistence (localStorage, cookies, DB)
- Authentication
- Analytics
- Sound
- Mobile‑specific layout variants — the current design is responsive via `clamp()` and works from ~360px wide up
- Additional moods, additional options, or a way to author options at runtime

## Files in this bundle

- `README.md` — this document
- `reference/happy-sad.html` — the working HTML prototype. Open it locally to see every animation, color, and pixel sprite in motion. Use it as the source of truth when this README is ambiguous.
